package HomeWork5;

public class Calculator {
    public static int addition(int firstNumber, int secondNumber) {
        int addition = firstNumber + secondNumber;
        return addition;
    }

    public static int subtraction(int firstNumber, int secondNumber) {
        int subtraction = firstNumber - secondNumber;
        return subtraction;
    }

    public static int multiplication(int firstNumber, int secondNumber) {
        int multiplication = firstNumber * secondNumber;
        return multiplication;
    }

    public static int division(int firstNumber, int secondNumber) {
        int division = firstNumber / secondNumber;
        return division;
    }
}
